import { isAdjacent, patternBonus } from "./patternDetector.js";

export function calculateProbabilities(cards, currentCard, patternMap) {
  const hiddenCards = cards.filter((card) => !card.revealed && !card.matched);
  const probabilities = {};

  if (!currentCard || hiddenCards.length === 0) return probabilities;

  const remainingSymbols = {};
  for (const card of hiddenCards) {
    remainingSymbols[card.symbol] = (remainingSymbols[card.symbol] || 0) + 1;
  }

  const baseChance = 100 / hiddenCards.length;

  for (const card of hiddenCards) {
    let probability = baseChance;

    if (card.known && card.symbol === currentCard.symbol) {
      probability = 92;
    }

    if (isAdjacent(card, currentCard)) {
      probability += 20;
    }

    probability += patternBonus(card, currentCard, patternMap);

    const frequency = remainingSymbols[card.symbol] || 1;
    if (frequency <= 1 && !card.known) {
      probability -= 5;
    }

    if (card.known && card.symbol !== currentCard.symbol) {
      probability = Math.max(2, probability - 35);
    }

    probabilities[card.id] = Math.max(1, Math.min(99, Math.round(probability)));
  }

  return probabilities;
}

export function getBestMove(cards, currentCard, probabilities) {
  if (!currentCard) return null;

  return cards
    .filter((card) => !card.revealed && !card.matched)
    .sort((a, b) => (probabilities[b.id] || 0) - (probabilities[a.id] || 0))[0] || null;
}
