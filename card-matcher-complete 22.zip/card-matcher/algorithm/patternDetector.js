export function isAdjacent(a, b) {
  const rowDiff = Math.abs(a.row - b.row);
  const colDiff = Math.abs(a.col - b.col);
  return rowDiff + colDiff === 1;
}

export function createPatternMap(cards) {
  const map = {};

  for (const card of cards) {
    if (!map[card.symbol]) map[card.symbol] = [];
    map[card.symbol].push({ row: card.row, col: card.col, id: card.id });
  }

  return map;
}

export function patternBonus(candidate, currentCard, patternMap) {
  if (!patternMap || !currentCard) return 0;

  const positions = patternMap[currentCard.symbol] || [];
  const realPairPosition = positions.find((pos) => pos.id !== currentCard.id);

  if (!realPairPosition) return 0;

  if (candidate.row === realPairPosition.row && candidate.col === realPairPosition.col) {
    return 45;
  }

  const distance =
    Math.abs(candidate.row - realPairPosition.row) +
    Math.abs(candidate.col - realPairPosition.col);

  if (distance === 1) return 10;
  return 0;
}
