export function applyInterference(cards) {
  const matchedVisible = cards.filter((card) => card.matched && card.revealed);

  if (matchedVisible.length === 0) return null;

  const target = matchedVisible[Math.floor(Math.random() * matchedVisible.length)];
  const pair = cards.find(
    (card) => card.id !== target.id && card.symbol === target.symbol && card.matched
  );

  target.matched = false;
  target.revealed = false;
  target.known = false;

  if (pair) {
    pair.matched = false;
  }

  return target;
}
