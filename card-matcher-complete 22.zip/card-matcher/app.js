import { calculateProbabilities, getBestMove } from "./algorithm/probabilityEngine.js";
import { createPatternMap } from "./algorithm/patternDetector.js";
import { applyInterference } from "./algorithm/interferenceManager.js";
import { renderCardGrid } from "./components/CardGrid.js";
import { renderScorePanel } from "./components/ScorePanel.js";

const symbols = [
  "★", "☽", "☀", "♠", "♥", "♦", "♣", "⚡", "🔥", "❄",
  "🐉", "🕷", "🃏", "⚔", "🛡", "💎", "🌀", "👁", "🌙", "🪄"
];

const state = {
  cards: [],
  selected: [],
  score: 0,
  flips: 0,
  matchedPairs: 0,
  mismatchStreak: 0,
  timeLeft: 60,
  timer: null,
  gameOver: false,
  probabilities: {},
  bestMoveId: null,
  patternMap: null,
  lastMessage: "Ready"
};

function shuffle(array) {
  const copy = [...array];
  for (let i = copy.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [copy[i], copy[j]] = [copy[j], copy[i]];
  }
  return copy;
}

function buildCards() {
  const deck = shuffle([...symbols, ...symbols]);
  return deck.map((symbol, index) => ({
    id: index,
    symbol,
    row: Math.floor(index / 8),
    col: index % 8,
    revealed: false,
    matched: false,
    known: false,
    probability: 0,
    interfered: false
  }));
}

function startGame() {
  clearInterval(state.timer);
  state.cards = buildCards();
  state.selected = [];
  state.score = 0;
  state.flips = 0;
  state.matchedPairs = 0;
  state.mismatchStreak = 0;
  state.timeLeft = 60;
  state.gameOver = false;
  state.probabilities = {};
  state.bestMoveId = null;
  state.patternMap = createPatternMap(state.cards);
  state.lastMessage = "Find all 20 pairs before time expires.";
  updateUI();

  state.timer = setInterval(() => {
    if (state.gameOver) return;
    state.timeLeft--;
    if (state.timeLeft <= 0) {
      state.timeLeft = 0;
      state.gameOver = true;
      state.lastMessage = "Time expired. Hisoka wins.";
      clearInterval(state.timer);
    }
    updateUI();
  }, 1000);
}

function flipCard(cardId) {
  if (state.gameOver) return;

  const card = state.cards.find((item) => item.id === cardId);
  if (!card || card.revealed || card.matched || state.selected.length >= 2) return;

  card.revealed = true;
  card.known = true;
  card.interfered = false;
  state.selected.push(card);
  state.flips++;

  state.probabilities = calculateProbabilities(state.cards, card, state.patternMap);
  state.cards.forEach((item) => {
    item.probability = state.probabilities[item.id] || 0;
  });

  if (state.selected.length === 1) {
    const best = getBestMove(state.cards, state.selected[0], state.probabilities);
    state.bestMoveId = best ? best.id : null;
    state.lastMessage = `Current aura: ${card.symbol}. Probability engine updated.`;
    updateUI();
    return;
  }

  checkPair();
}

function checkPair() {
  const [first, second] = state.selected;

  if (first.symbol === second.symbol) {
    first.matched = true;
    second.matched = true;
    state.score += 10;
    state.matchedPairs++;
    state.mismatchStreak = 0;
    state.selected = [];
    state.bestMoveId = null;
    state.lastMessage = `Match found: ${first.symbol}. +10 points.`;

    if (state.matchedPairs === 20) {
      state.gameOver = true;
      state.lastMessage = "Victory. All 20 pairs found.";
      clearInterval(state.timer);
    }

    updateUI();
    return;
  }

  state.mismatchStreak++;
  state.lastMessage = `Mismatch. Streak: ${state.mismatchStreak}/3.`;

  setTimeout(() => {
    first.revealed = false;
    second.revealed = false;
    state.selected = [];
    state.bestMoveId = null;

    if (state.mismatchStreak >= 3) {
      const result = applyInterference(state.cards);
      state.mismatchStreak = 0;

      if (result) {
        result.interfered = true;
        state.matchedPairs = Math.max(0, state.matchedPairs - 1);
        state.lastMessage = `Hisoka interference! A matched ${result.symbol} card flipped back down.`;
      } else {
        state.lastMessage = "Hisoka tried to interfere, but no matched card was available.";
      }
    }

    updateUI();

    setTimeout(() => {
      state.cards.forEach((card) => card.interfered = false);
      updateUI();
    }, 1300);
  }, 780);

  updateUI();
}

function updateUI() {
  renderScorePanel(document.getElementById("scorePanel"), state);

  renderCardGrid({
    root: document.getElementById("cardGrid"),
    cards: state.cards,
    bestMoveId: state.bestMoveId,
    onFlip: flipCard
  });

  document.getElementById("gameStatus").textContent = state.gameOver ? "Game Over" : state.lastMessage;

  if (state.selected.length === 0) {
    document.getElementById("selectedInfo").textContent =
      "No active card. Flip one card to activate probability hints.";
  } else {
    const card = state.selected[state.selected.length - 1];
    document.getElementById("selectedInfo").textContent = [
      `Card ID: ${card.id}`,
      `Symbol: ${card.symbol}`,
      `Position: row ${card.row + 1}, column ${card.col + 1}`,
      `Known by memory: ${card.known ? "YES" : "NO"}`
    ].join("\n");
  }

  const best = state.cards.find((card) => card.id === state.bestMoveId);
  document.getElementById("engineInfo").textContent = best
    ? `Best move: Card ${best.id}\nProbability: ${best.probability}%\nLogic: memory + adjacency aura + hidden pattern.`
    : "Flip one card first. Then the engine will rank all hidden cards.";

  document.getElementById("interferenceInfo").textContent =
    `Mismatch streak: ${state.mismatchStreak}/3\nAfter 3 mismatches, one random matched card flips back down.`;
}

document.getElementById("newGameBtn").addEventListener("click", startGame);

document.getElementById("hintBtn").addEventListener("click", () => {
  if (!state.selected.length) {
    state.lastMessage = "Flip one card first before asking for the best move.";
    updateUI();
    return;
  }

  const best = getBestMove(state.cards, state.selected[0], state.probabilities);
  state.bestMoveId = best ? best.id : null;
  state.lastMessage = best
    ? `Best move highlighted: card ${best.id} (${best.probability}%).`
    : "No hidden candidate available.";
  updateUI();
});

startGame();
