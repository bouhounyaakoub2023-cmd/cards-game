# Greed Island: The Cards Matcher

A high-difficulty Memory Match game with probability hints, pattern detection, and Hisoka's Nen interference.

## Run

Because the project uses JavaScript modules, run it with a local server:

```bash
python -m http.server 8000
```

Then open:

```text
http://localhost:8000
```

## Rules

- 40 cards arranged in an 8x5 grid.
- 20 unique symbols, each appears twice.
- Flip two cards.
- Match: cards stay revealed and score +10.
- Mismatch: cards flip back.
- Complete all pairs before the 60-second timer ends.

## Probability Engine

After a card is flipped, every face-down card displays a probability value from 0 to 100.

The probability engine uses:

1. Remaining hidden cards.
2. Known memory from previously flipped cards.
3. Positional patterns.
4. Adjacent cards receive a +20% aura bonus.
5. Symbol frequency logic.
6. Hidden pair-position pattern bonus.

## Nen Interference

After 3 mismatches in a row:
- Hisoka interferes.
- One random matched card flips back down.
- Its pair is unlocked again.
- The player must rediscover the pair.

## Best Move Suggestion

The Best Move button highlights the hidden card with the highest calculated probability.

## Structure

```text
card-matcher/
├── index.html
├── style.css
├── app.js
├── algorithm/
│   ├── probabilityEngine.js
│   ├── patternDetector.js
│   └── interferenceManager.js
├── components/
│   ├── CardGrid.js
│   ├── ProbabilityOverlay.js
│   └── ScorePanel.js
└── README.md
```
