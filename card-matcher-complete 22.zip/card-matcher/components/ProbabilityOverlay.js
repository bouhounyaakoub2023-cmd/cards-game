export function probabilityBadge(card) {
  if (card.revealed || card.matched) return "";
  const value = Number.isFinite(card.probability) ? card.probability : 0;
  return `<span class="probability">${value}%</span>`;
}
