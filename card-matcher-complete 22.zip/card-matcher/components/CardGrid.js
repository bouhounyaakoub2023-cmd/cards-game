import { probabilityBadge } from "./ProbabilityOverlay.js";

export function renderCardGrid({ root, cards, bestMoveId, onFlip }) {
  root.innerHTML = "";

  for (const card of cards) {
    const cardEl = document.createElement("button");
    cardEl.className = [
      "card",
      card.revealed ? "revealed" : "",
      card.matched ? "matched" : "",
      card.id === bestMoveId ? "best" : "",
      card.interfered ? "interfered" : ""
    ].filter(Boolean).join(" ");

    cardEl.setAttribute("aria-label", `Card ${card.id}`);
    cardEl.onclick = () => onFlip(card.id);

    cardEl.innerHTML = `
      <div class="card-inner">
        <div class="face front">
          ${probabilityBadge(card)}
        </div>
        <div class="face back">
          <div class="symbol">${card.symbol}</div>
        </div>
      </div>
    `;

    root.appendChild(cardEl);
  }
}
