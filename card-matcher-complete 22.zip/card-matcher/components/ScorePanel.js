export function renderScorePanel(root, state) {
  root.innerHTML = `
    <div class="score-card">
      <strong>${state.timeLeft}s</strong>
      <small>Timer</small>
    </div>
    <div class="score-card">
      <strong>${state.score}</strong>
      <small>Score</small>
    </div>
    <div class="score-card">
      <strong>${state.flips}</strong>
      <small>Flips</small>
    </div>
    <div class="score-card">
      <strong>${state.matchedPairs}/20</strong>
      <small>Pairs</small>
    </div>
    <div class="score-card danger">
      <strong>${state.mismatchStreak}/3</strong>
      <small>Mismatch</small>
    </div>
    <div class="score-card">
      <strong>${Math.max(0, 20 - state.matchedPairs)}</strong>
      <small>Remaining</small>
    </div>
  `;
}
